[![codebeat badge](https://codebeat.co/badges/b9d48414-5fcb-4d9c-90da-40d093fdc234)](https://codebeat.co/projects/github-com-seanpai96-dinnersys-android-master)<br/>
# DinnerSystem App for Android
This is the first project I've made by Kotlin, and I'm still learning more about it. It seems stable now, but still there might be some flaws.
<br/>
Same as the iOS version, it can't compete with those commercial applications, but we are trying our best as an individual developer and make more people feel convienent.
<br/>
# Used APIs
I used Firebase and Crashlytics, and Volley for HTTP request. All others are anko and native Kotlin APIs.
